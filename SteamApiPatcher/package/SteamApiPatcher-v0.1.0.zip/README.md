# Steam API Upgrade

A patcher that replaces the Steam API + Facepunch.Steamworks API with a more recent version to allow the use of more modern API features such as Steam Timelines API for Game Recording.
